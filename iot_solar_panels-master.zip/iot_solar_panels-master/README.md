# SFDX  App

## Dev, Build and Test
To test via Workbench, use the following url:

/services/data/v41.0/sobjects/Solar_Panel_Monitor__e

and the following Sample (where Device_Id__c is the Solar Panel Serial Number on your test Asset)

<pre>
{
"Device_Id__c":"ABCD1234",
"Health__c":100
}
</pre>

## Resources


## Description of Files and Directories


## Issues


